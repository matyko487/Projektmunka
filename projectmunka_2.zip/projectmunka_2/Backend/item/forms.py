from django import forms
from multiupload.fields import MultiFileField
from .models import Item, ItemImage

CATEGORY = 'w-50 h-15 py-4 px-6 rounded-xl border'
NAME = 'w-50 h-15 py-4 px-3 rounded-xl border'
DESC = 'w-50 h-20 py-4 px-3 rounded-xl border'
PRICE = 'w-50 h-15 py-4 px-3 rounded-xl border'


class NewItemForm(forms.ModelForm):

    images = MultiFileField(
        min_num=1,
        max_num=5,  # Ezt módosítsd az igényeid szerint
        max_file_size=1024*1024*5,  # Ezt is módosítsd az igényeid szerint
        label="Képek"
    )

    class Meta:
        model = Item
        fields = ('category','name','description','price'
                  )
        
        widgets = {
            'category': forms.Select(attrs={'class': CATEGORY}),

            'name': forms.TextInput( attrs={'class': NAME}),
            
            'description': forms.Textarea(attrs={'class': DESC}),

            'price': forms.TextInput(attrs={'class': PRICE}),

            
        }
        labels = {
            'category': 'Kategória',
            'name': 'Név',
            'description': 'Leírás' ,
            'price': 'Ár',
            # 'image': 'Képek'

        }

class EditItemForm(forms.ModelForm):
    images = MultiFileField(
        min_num=0,
        max_num=5,  # Ezt módosítsd az igényeid szerint
        max_file_size=1024*1024*5,  # Ezt is módosítsd az igényeid szerint
        label="Képek"
    )


    class Meta:
        model = Item
        fields = ('name','description','price', 'is_sold')
        widgets = {
            'name': forms.TextInput(attrs={'class': NAME}),

            'description': forms.Textarea(attrs={'class': DESC}),

            'price': forms.TextInput(attrs={'class': PRICE }),

        }
        labels = {
            'name': 'Név',
            'description': 'Leírás' ,
            'price': 'Ár',

        }
    def save(self, commit=True):
        item = super().save(commit)
        
        for uploaded_image in self.cleaned_data['images']:
            item_image = ItemImage(item=item, image=uploaded_image)
            item_image.save()

        return item
