from django.shortcuts import render, redirect
from django.contrib.auth import logout

from item.models import Category, Item

from .forms import SignupForm

# def index(request):
#     items = Item.objects.filter(is_sold=False)[0:6]
#     categories = Category.objects.all
#     return render(request, 'core/index.html', {
#         'categories': categories,
#         'items': items})

def index(request, category_id=None):
    items = Item.objects.filter(is_sold=False)[0:6]
    categories = Category.objects.all()

    if category_id is not None:
        # Ha van megadva egy category_id, akkor szűrjük az elemeket erre a kategória azonosítóra
        items = Item.objects.filter(is_sold=False, category_id=category_id)[0:6]

    return render(request, 'core/index.html', {
        'categories': categories,
        'items': items,
    })

def view_logout(request):
    logout(request)
    return render(request, 'core/logout.html')

def contact(request):
    return render(request, 'core/contact.html')

def signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)

        if form.is_valid():
            form.save()

            return redirect('/signin/')
    else:
        form = SignupForm()
    return render(request, 'core/signup.html', {
        'form': form
    })
