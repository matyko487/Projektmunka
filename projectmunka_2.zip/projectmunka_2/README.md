# Projektmunka2

Futtatás:
1.pip install -r EzekAPipekKellenek.txt
2.python manage.py makemigrations
3.python manage.py migrate
4.python manage.py runserver

A frontend django html fájlokból épül fel, a Backend mappában található.